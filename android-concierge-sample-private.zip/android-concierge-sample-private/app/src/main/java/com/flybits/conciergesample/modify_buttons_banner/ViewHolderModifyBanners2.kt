package com.flybits.conciergesample.modify_buttons_banner

import android.view.View
import android.widget.FrameLayout
import androidx.recyclerview.widget.RecyclerView
import com.flybits.conciergesample.R

class ViewHolderModifyBanners2(v: View) : RecyclerView.ViewHolder(v) {
    var frameLayout: FrameLayout = v.findViewById(R.id.embeded_concierge_recycler)
}
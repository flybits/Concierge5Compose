package com.flybits.sample.tdus

import androidx.fragment.app.Fragment

interface Interaction {
    fun updateConcierge(layout : Int, fragment : Fragment)
}
